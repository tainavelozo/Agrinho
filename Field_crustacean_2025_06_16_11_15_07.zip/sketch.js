let x = 50; // Posição do veículo
let sunX = 100; // Sol
let cloudX = 0; // Movimento das nuvens
let horseX = 200; // Posição do cavalo
let eating = true; // Se o cavalo está comendo ou não

function setup() {
  createCanvas(1000, 400);
}

function draw() {
  // Gradiente de fundo (transição do céu)
  background(135, 206, 235); // Céu azul
  drawSky();

  // Desenhando o campo (lado esquerdo)
  drawField();

  // Desenhando a cidade (lado direito)
  drawCity();

  // Desenhando a estrada
  drawRoad();

  // Desenhando o veículo que vai do campo para a cidade
  drawVehicle();

  // Desenhando o cavalo comendo
  drawHorse();

  // Movendo o veículo
  x += 1;
  if (x > width) x = -100; // Se o veículo ultrapassar a tela, ele volta

  // Movendo o sol (criar a sensação de um dia passando)
  sunX += 0.5;
  if (sunX > width) sunX = -80; // O sol sai da tela e entra novamente

  // Movendo as nuvens
  cloudX += 0.2;
  if (cloudX > width) cloudX = -200;
}

function drawSky() {
  // Céu com efeito de gradiente (sol está indo para o lado direito)
  let skyColor = map(sunX, 0, width, 135, 255); // Mudando o céu conforme o sol
  background(skyColor, 206, 235);

  // Nuvens flutuando no céu
  fill(255, 255, 255, 180);
  ellipse(cloudX, 60, 100, 50);
  ellipse(cloudX + 300, 80, 120, 60);
  ellipse(cloudX + 600, 40, 100, 50);

  // Sol no céu
  fill(255, 204, 0);
  ellipse(sunX, 80, 80, 80);
}

function drawField() {
  // Campos
  fill(34, 139, 34);
  rect(0, 300, width / 2, 100); // Campo de grama

  // Plantação de milho
  for (let i = 20; i < width / 2; i += 30) {
    fill(218, 165, 32);
    rect(i, 280, 5, 20);
  }

  // Fazendo o celeiro
  fill(139, 69, 19);
  rect(100, 230, 80, 60); // Corpo do celeiro
  fill(165, 42, 42);
  triangle(90, 230, 180, 230, 135, 190); // Telhado

  // Árvore no campo
  fill(101, 67, 33);
  rect(200, 250, 10, 40); // Tronco
  fill(34, 139, 34);
  ellipse(205, 240, 40, 40); // Folhagem

  // Gado
  fill(255);
  ellipse(300, 270, 30, 30); // Vaca
  ellipse(330, 270, 30, 30); // Vaca

  // Rio
  fill(70, 130, 180);
  beginShape();
  vertex(0, 350);
  vertex(100, 340);
  vertex(150, 360);
  vertex(200, 350);
  vertex(250, 370);
  vertex(300, 350);
  vertex(300, 370);
  vertex(400, 350);
  vertex(500, 360);
  vertex(600, 350);
  vertex(700, 370);
  vertex(800, 350);
  vertex(1000, 360);
  vertex(1000, 400);
  vertex(500, 400);
  endShape(CLOSE);
}

function drawCity() {
  // Prédios
  for (let i = 420; i < width; i += 60) {
    fill(150);
    rect(i, random(180, 240), 50, random(100, 150)); // Prédios
    fill(255);
    for (let y = 190; y < 350; y += 20) {
      rect(i + 10, y, 5, 10); // Janelas
      rect(i + 30, y, 5, 10);
    }
  }

  // Fábrica e poluição
  fill(128, 128, 128);
  rect(750, 230, 100, 100); // Fábrica
  fill(255, 255, 255, 100);
  for (let i = 0; i < 5; i++) {
    ellipse(800 + i * 10, 220 - i * 10, 20, 20); // Fumaça
  }

  // Estrada da cidade
  fill(169, 169, 169);
  rect(width / 2, 300, width / 2, 100); // Asfalto

  // Faixas de pedestres
  for (let i = 0; i < width; i += 40) {
    fill(255);
    rect(i + 420, 370, 20, 10);
  }

  // Transporte público: ônibus
  fill(255, 165, 0);
  rect(650, 350, 60, 30); // Corpo do ônibus
  fill(0);
  ellipse(660, 380, 15, 15);
  ellipse(690, 380, 15, 15);
}

function drawRoad() {
  fill(50);
  rect(0, 350, width, 50); // Asfalto da estrada

  // Faixa de pedestres
  for (let i = 0; i < width; i += 40) {
    fill(255);
    rect(i, 370, 20, 10);
  }
}

function drawVehicle() {
  // Caminhão
  fill(255, 0, 0);
  rect(x, 320, 60, 30);
  fill(0);
  ellipse(x + 10, 350, 15, 15);
  ellipse(x + 50, 350, 15, 15);
}

function drawHorse() {
  // Cavalo comendo capim
  fill(139, 69, 19); // Corpo do cavalo
  ellipse(horseX, 280, 60, 40); // Corpo
  fill(255); // Cabeça do cavalo
  ellipse(horseX + 35, 250, 30, 20); // Cabeça

  // Posições das patas
  fill(139, 69, 19);
  rect(horseX - 15, 300, 10, 30); // Perna dianteira
  rect(horseX + 10, 300, 10, 30); // Perna traseira

  // Cauda
  stroke(139, 69, 19);
  strokeWeight(5);
  line(horseX - 30, 290, horseX - 50, 310);

  // Boca do cavalo (comendo capim)
  if (eating) {
    fill(34, 139, 34); // Capim
    rect(horseX - 10, 280, 20, 5); // Capim no chão
  }
}
